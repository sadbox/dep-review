print('EVIL sitecustomize (purelib) ran at startup')
