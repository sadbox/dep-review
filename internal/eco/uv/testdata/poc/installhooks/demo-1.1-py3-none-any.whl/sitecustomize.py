print('EVIL sitecustomize ran at startup')
