def main():
    print('demo')
def evil():
    print('EVIL console script ran')
