WHICH='pure'
